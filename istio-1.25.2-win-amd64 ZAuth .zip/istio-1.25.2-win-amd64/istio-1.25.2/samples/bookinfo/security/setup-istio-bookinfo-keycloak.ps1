# Start Minikube
minikube start --cpus=4 --memory=8192 --driver=docker

# Enable Istio addon (or install manually if using your own Istio)
minikube addons enable ingress
minikube tunnel --alsologtostderr &

# Set env
$ISTIO_HOME = "D:\ZeroTrustAuth\istio-1.25.2-win-amd64\istio-1.25.2"
cd $ISTIO_HOME

# Install Istio
.\bin\istioctl install --set profile=demo -y

# Label default namespace
kubectl label namespace default istio-injection=enabled --overwrite

# Deploy Bookinfo
kubectl apply -f .\samples\bookinfo\platform\kube\bookinfo.yaml

# Wait for pods to be ready
Write-Host "Waiting for Bookinfo pods to be ready..."
kubectl wait --for=condition=ready pod -l app=productpage -n default --timeout=180s

# Deploy Gateway
kubectl apply -f .\samples\bookinfo\networking\bookinfo-gateway.yaml

# Deploy destination rules
kubectl apply -f .\samples\bookinfo\networking\destination-rule-all.yaml

# Add Helm repo and update
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update

# Install Keycloak
helm install keycloak bitnami/keycloak --namespace keycloak --create-namespace `
  --set auth.adminUser=admin,auth.adminPassword=adminpassword,service.type=ClusterIP

# Wait for Keycloak to be ready
kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=keycloak -n keycloak --timeout=180s

# Port-forward Keycloak (run separately in terminal)
Start-Process powershell -ArgumentList "kubectl port-forward svc/keycloak 8081:80 -n keycloak"

# Apply mTLS policy
@"
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: default
  namespace: default
spec:
  mtls:
    mode: STRICT
"@ | Out-File mtls-strict.yaml -Encoding utf8
kubectl apply -f mtls-strict.yaml

# Create JWT auth policy
@"
apiVersion: security.istio.io/v1beta1
kind: RequestAuthentication
metadata:
  name: bookinfo-jwt
  namespace: default
spec:
  selector:
    matchLabels:
      app: productpage
  jwtRules:
  - issuer: "http://localhost:8081/realms/master"
    jwksUri: "http://localhost:8081/realms/master/protocol/openid-connect/certs"
"@ | Out-File request-auth.yaml -Encoding utf8
kubectl apply -f request-auth.yaml

# Create authorization policy
@"
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: bookinfo-require-jwt
  namespace: default
spec:
  selector:
    matchLabels:
      app: productpage
  action: ALLOW
  rules:
  - from:
    - source:
        requestPrincipals: ["*"]
"@ | Out-File authz-policy.yaml -Encoding utf8
kubectl apply -f authz-policy.yaml

# Get ingress IP (through Minikube tunnel)
$ip = "127.0.0.1" # use minikube tunnel, so it's localhost
$url = "http://$ip/productpage"

# Output to browser
Start-Process $url
Write-Host "If JWT token is not sent, you should see 403. Use ModHeader plugin to add Authorization: Bearer <JWT_TOKEN> to test."
